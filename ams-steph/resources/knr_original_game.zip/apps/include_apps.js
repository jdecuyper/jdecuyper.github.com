(function() {
  document.writeln('<script type="text/javascript" src="apps/common/Global.js"></script>');
  document.writeln('<script type="text/javascript" src="apps/common/Const.js"></script>');
  document.writeln('<script type="text/javascript" src="apps/preloader/PreloaderApp.js"></script>');
  document.writeln('<script type="text/javascript" src="apps/main/MainAppStandardSteps.js"></script>');
  document.writeln('<script type="text/javascript" src="apps/main/MainApp.js"></script>');
  document.writeln('<script type="text/javascript" src="apps/main/SpriteBuilder.js"></script>');
  document.writeln('<script type="text/javascript" src="apps/main/Attract.js"></script>');
  document.writeln('<script type="text/javascript" src="apps/main/TeamPicker.js"></script>');
  document.writeln('<script type="text/javascript" src="apps/main/PenaltyMatch.js"></script>');
  document.writeln('<script type="text/javascript" src="apps/main/PenaltyRound.js"></script>');
  

}).call(this);