Const = new Object();
Const.TEMPO_MINIMO_PRELOADING = 1000;