function initPreloaderApp(){
  Global._preloaderApp = $(".preloaderApp");
}

function hidePreloaderapp(){
  Global._preloaderApp.hide();
}

function showPreloaderapp(){
  Global._preloaderApp.show();
}